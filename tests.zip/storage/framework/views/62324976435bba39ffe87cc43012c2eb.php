<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Panel de control</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <p>Welcome to this beautiful admin panel.</p>
    <div class="container-fluid">
        <div class="col-md-6 col-sm-6">
            <h1><?php echo e($chart->options['chart_title']); ?></h1>
            <?php echo $chart->renderHtml(); ?>

        </div>
        <div class="col-md-6 col-sm-6">

        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo $chart->renderChartJsLibrary(); ?>

    <?php echo $chart->renderJs(); ?>

    <script> console.log("Hi, I'm using the Laravel-AdminLTE package!"); </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\entrestats\resources\views/home.blade.php ENDPATH**/ ?>