<?php $__env->startSection('title', 'Create IMC'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex align-items-center justify-content-center vh-100">
        <div class="col-md-8">
            <h1 class="text-center mb-4">Inserta los datos para calcular tu IMC</h1>
            <hr style="border: 1px solid black;">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <form action="<?php echo e(route('imc.calculateImc')); ?>" method="POST" class="row g-3">
                <?php echo csrf_field(); ?>
                <div class="col-md-4">
                    <label for="sx">Sexo:</label>
                    <select id="sx" class="form-select form-select-lg mb-3" name="sexo">
                        <option value="" selected>Selecciona</option>
                        <option value="H">Hombre</option>
                        <option value="M">Mujer</option>
                    </select>
                </div>

                <div class="col-md-4">
                    <label for="cms">Altura (cm):</label>
                    <input type="number" id="cms" name="cms" value="<?php echo e(old('cms')); ?>" class="form-control">
                </div>

                <div class="col-md-4">
                    <label for="kgs">Peso (kg):</label>
                    <input type="number" id="kgs" name="kgs" value="<?php echo e(old('kgs')); ?>" class="form-control">
                </div>

                <div class="text-center mt-4">
                    <button type="submit" class="btn btn-success">Guardar</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <style>
        html, body {
            height: 100%;
            margin: 0;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\entrestats\resources\views/imc/index.blade.php ENDPATH**/ ?>