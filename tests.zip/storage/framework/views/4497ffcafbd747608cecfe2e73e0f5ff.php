<?php $__env->startSection('title', 'Estadisticas'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <h1>INSERTA AQUI CUANTO PESO HAS LEVANTADO:</h1>
        <?php if($errors->any()): ?>
            <div>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if(session('success')): ?>
            <div>
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('estadisticas.store')); ?>" method="POST" class="row g-3">
            <?php echo csrf_field(); ?>
            <div class="col-md-6">
                <label for="pecho">Pecho:</label>
                <input type="number" id="pecho" name="pecho" value="<?php echo e(old('pecho')); ?>">
            </div>

            <div class="col-md-6">
                <label for="biceps">Bíceps:</label>
                <input type="number" id="biceps" name="biceps" value="<?php echo e(old('biceps')); ?>">
            </div>
            <div class="col-md-6">
                <label for="pierna">Pierna:</label>
                <input type="number" id="pierna" name="pierna" value="<?php echo e(old('pierna')); ?>">
            </div>
            <div class="col-md-6">
                <label for="hombro">Hombro:</label>
                <input type="number" id="hombro" name="hombro" value="<?php echo e(old('hombro')); ?>">
            </div>
            <div class="col-md-12">
                <label for="dia">Día:</label>
                <input type="datetime-local" id="dia" name="dia" value="<?php echo e(old('dia')); ?>">
            </div>
            <button type="submit">Guardar</button>
        </form>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\entrestats\resources\views/estadisticas/create.blade.php ENDPATH**/ ?>