<?php $__env->startSection('title', 'Create IMC'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex align-items-center justify-content-center vh-100">
    <div class="col-md-8">
        <h1 class="text-center mb-4">Resultado del IMC</h1>
        <hr style="border: 1px solid black;">
        <div style="col-lg-12 col-md-12 col-sm-12">
             <div style="col-lg-6 col-md-6 col-sm-6">
        <?php if(isset($calculoImc)): ?>
           
                <h2>Tu IMC es: <strong><?php echo e(number_format($calculoImc, 2)); ?></strong></h2>
            
            <!-- Interpretación del IMC -->
             
            <?php if($sexo == 'M'): ?>
                
                    <h3>Eres mujer</h3>
               
            <?php else: ?>
               
                    <h3>Eres hombre</h3>
               
            <?php endif; ?>
            <?php if($calculoImc < 18.5 && $sexo == 'H'): ?>
                
                    <h1 style="color:red">Estás por debajo del peso ideal.</h1>
               
            <?php elseif($calculoImc < 24.9 && $sexo == 'H'): ?>
                
                    <h2 style="color:green;">Estás en el peso ideal.</h2>
                
            <?php elseif($calculoImc < 29.9 && $sexo == 'H'): ?>
               
                    <h2 style="color:orange">Estás en sobrepeso.</h2>
               
            <?php elseif($calculoImc >= 30 && $sexo == 'H'): ?>
                
                    <h1 style="color:red">Estás en obesidad.</h1>
               
            <?php endif; ?>

            <?php if($calculoImc < 18.5 && $sexo == 'M'): ?>
                
                    <h1 style="color:red">Estás por debajo del peso ideal.</h1>
                
            <?php elseif($calculoImc >= 18.5 && $calculoImc <= 24.9 && $sexo == 'M'): ?>
               
                    <h2 style="color:green;">Estás en el peso ideal.</h2>
              
            <?php elseif($calculoImc >= 25 && $calculoImc <= 29.9 && $sexo == 'M'): ?>
                
                    <h2 style="color:orange">Estás en sobrepeso.</h2>
                
            <?php elseif($calculoImc >= 30 && $sexo == 'M'): ?>
                    <h1 style="color:red">Estás en obesidad.</h1>
               
            <?php endif; ?>
            </div>
            </div>
        <?php endif; ?>
        <div class="container-fluid row justify-content-center">
            <a href="<?php echo e(route('imc.index')); ?>" class="btn btn-warning">Calcular otro IMC</a>
        </div>
    </div>
</div>


    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('css'); ?>
    
    
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('js'); ?>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\entrestats\resources\views/imc/resultado.blade.php ENDPATH**/ ?>